Time Rush — Static Website
--------------------------

This is a polished, responsive static website built for "Time Rush" (luxury watches).
It includes:
- index.html (main landing + collection)
- assets/
  - css/styles.css
  - js/script.js
  - images/logo.png (your provided logo)

How to use:
1. Unzip the package.
2. Open index.html in a modern browser.
3. The site is static; product data is included inside the JS as sampleProducts.
4. Replace product images in assets/images and update product data in assets/js/script.js to customize.

Notes:
- This is a static demo suitable for hosting on Netlify, GitHub Pages, or any static host.
- For an ecommerce backend, integrate with Shopify, Stripe, or a custom backend.
